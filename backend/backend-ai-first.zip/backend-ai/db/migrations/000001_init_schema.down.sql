DROP TABLE IF EXISTS verifications;
